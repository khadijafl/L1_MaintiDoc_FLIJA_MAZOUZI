# Prompt : Documentation technique des équipements d'une station de dessalement d'eau de mer

Nous avons choisi le domaine du **dessalement de l'eau de mer** pour notre projet. Je souhaite identifier et étudier deux équipements industriels essentiels au fonctionnement d'une station de dessalement.

Pour chacun des deux équipements, réalise une documentation technique structurée selon les exigences suivantes :

## 1. Identification des équipements
- Présenter les deux équipements les plus pertinents et importants dans une station de dessalement.
- Expliquer leur rôle, leur fonctionnement et leur importance dans le processus de dessalement.
- Décrire brièvement leurs principaux composants.

## 2. Identification des problématiques
Pour chaque équipement, identifier entre **30 et 50 problématiques ou pannes différentes**, réellement susceptibles de se produire dans une installation industrielle de dessalement.

Pour chaque problématique, préciser :
- Le nom de la panne ou du problème.
- Une description technique détaillée.
- Les causes possibles.
- Les symptômes et les signes de détection.
- Les conséquences sur le fonctionnement de l'équipement et sur la production d'eau dessalée.
- Les méthodes de diagnostic et de vérification.

## 3. Création des rapports PDF
Créer **un rapport PDF individuel pour chaque problématique**, avec une longueur de **2 à 3 pages par rapport**.

Chaque rapport doit contenir :
1. Le nom de l'équipement concerné.
2. Le titre et la description de la problématique.
3. Les causes possibles.
4. Les symptômes et les conséquences.
5. Les méthodes de diagnostic.
6. Une **solution corrective détaillée et applicable**, présentée sous forme d'étapes claires.
7. Les outils, les pièces de rechange et les ressources nécessaires.
8. Les mesures de sécurité à respecter pendant l'intervention.
9. Les vérifications à effectuer après la réparation.
10. Les recommandations de maintenance préventive pour éviter la réapparition du problème.

## 4. Illustrations et documentation visuelle
Chaque rapport doit obligatoirement contenir des illustrations spécifiques à la problématique étudiée :

- **Au moins une image réelle** représentant la panne ou le phénomène concerné, provenant d'une source fiable en ligne.
- Un schéma technique annoté permettant de comprendre le problème lorsque cela est pertinent.
- Un diagramme BPMN illustrant le processus de diagnostic et de résolution de la panne.

Les images doivent correspondre précisément à la problématique traitée. Ne pas utiliser une image générique qui représente uniquement l'équipement sans montrer le problème étudié.

Pour chaque image ou schéma provenant d'une source externe, indiquer :
- Le lien direct vers la source.
- Le nom du site ou de l'organisme.
- La référence ou le crédit de l'image.
- La licence ou les conditions de réutilisation, si elles sont disponibles.

**Important :** ne jamais inventer une image, une référence, une source ou un lien. Si aucune photographie réelle fiable n'est disponible pour une problématique, le signaler clairement et proposer une illustration technique complémentaire.

## 5. Exigences de qualité
- Rédiger les rapports en français technique, avec une terminologie industrielle précise.
- Utiliser des informations provenant de sources fiables : fabricants, documentation technique, normes, articles scientifiques et organismes spécialisés.
- Adapter les solutions aux équipements utilisés dans les stations de dessalement par osmose inverse.
- Éviter les répétitions entre les différentes problématiques.
- Distinguer clairement les faits documentés, les recommandations générales et les procédures qui nécessitent une validation du fabricant.
- Ne pas proposer de procédures dangereuses ou de valeurs techniques sans justification.

## 6. Organisation finale des livrables
Organiser les documents de manière claire :
- Un dossier pour le premier équipement, contenant ses 30 à 50 rapports PDF.
- Un dossier pour le deuxième équipement, contenant ses 30 à 50 rapports PDF.
- Un document récapitulatif présentant les deux équipements et la liste de toutes les problématiques étudiées.
- Une bibliographie générale regroupant les sources utilisées.

Chaque PDF doit être autonome, bien structuré, illustré et directement exploitable comme documentation technique dans notre projet d'assistance intelligente à la maintenance industrielle.

**Objectif final :** constituer une base documentaire technique fiable permettant à un assistant IA de reconnaître une problématique de maintenance, de retrouver le rapport PDF correspondant et de fournir à l'utilisateur un diagnostic ainsi qu'une solution corrective détaillée et illustrée.